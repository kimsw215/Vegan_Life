/**
 * Package containing classes for Friends API responses.
 */
package com.kakao.friends.response;