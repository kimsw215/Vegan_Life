/**
 * Provide HTTP network module used throughout the SDK. Classes in this package are subject to change
 * at any time so use at your own discretion.
 */
package com.kakao.network;