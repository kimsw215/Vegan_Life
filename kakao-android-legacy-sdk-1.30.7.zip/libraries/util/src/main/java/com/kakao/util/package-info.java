/**
 * Provide Utlity classes and methods that are used throughout all modules of the SDK. Classes in this package are subject to change and removal at any time so please use at your own discretion.
 */
package com.kakao.util;