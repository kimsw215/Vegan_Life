/**
 * Provide KakaoTalk API.
 */
package com.kakao.kakaotalk;