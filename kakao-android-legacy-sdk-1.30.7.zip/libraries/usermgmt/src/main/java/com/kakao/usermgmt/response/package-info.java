/**
 * Provides response models for User API.
 */
package com.kakao.usermgmt.response;