package com.kakao.auth.helper;

import com.kakao.test.common.KakaoTestCase;

import org.junit.Before;
import org.junit.Test;

/**
 * @author kevin.kang. Created on 2017. 8. 14..
 */

public class AESEncryptorTest extends KakaoTestCase {
    @Before
    public void setup() {
        super.setup();
    }

    @Test
    public void possibleCandidate() {
    }
}
