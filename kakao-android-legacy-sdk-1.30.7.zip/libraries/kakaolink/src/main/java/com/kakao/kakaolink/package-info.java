/**
 * 카카오링크 메세지를 통해 메세지를 전송할 수 있는 API를 제공한다.
 */
package com.kakao.kakaolink;