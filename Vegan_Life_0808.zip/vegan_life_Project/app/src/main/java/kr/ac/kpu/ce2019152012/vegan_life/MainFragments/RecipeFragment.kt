package kr.ac.kpu.ce2019152012.vegan_life.MainFragments

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kr.ac.kpu.ce2019152012.vegan_life.R

class RecipeFragment : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.calendar_fragment)
    }
}